deretan_angka = []

while True:
    input_angka = input("Masukkan angka (atau ketik 'done' untuk selesai): ")
    if input_angka.lower() == 'done':
        break
    else:
        if input_angka.isdigit():
            deretan_angka.append(int(input_angka))
        else:
            print("Input tidak valid. Silakan masukkan angka atau 'done' untuk selesai.")

print("List angka yang dimasukkan:", deretan_angka)

if deretan_angka:
    print("Nilai maksimum:", max(deretan_angka))
    print("Nilai minimum:", min(deretan_angka))
else:
    print("List kosong, tidak ada nilai maksimum dan minimum.")
    

