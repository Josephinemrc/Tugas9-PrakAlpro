def tiga_nilai_tertinggi(listnya):
    listnya.sort(reverse = True)
    print(listnya)
    
    tiga_terbesar = listnya[:3]
    
    
    return tiga_terbesar

listnya = [80,30,60,50,70]
    
tiga_terbesar = tiga_nilai_tertinggi(listnya)

print("tiga nilai terbesar(dimulai dari yang paling tinggi) adalah: ", tiga_terbesar)



