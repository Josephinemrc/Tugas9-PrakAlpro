print("\n\n===== Kata Unik =====\n")
teks = []
with open("berita.txt","r", encoding="utf8") as file:
    for line in file:
        if line.startswith("="or ""):
            continue
        else:
            a = line.split(" " or "\n")
            print(a)
            
            